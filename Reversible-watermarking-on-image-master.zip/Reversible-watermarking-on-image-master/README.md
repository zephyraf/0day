# Reversible-watermarking-on-an-image-using-MATLAB
The work is based on histogram shifting technique. This work utilizes maximum point and the minimum point for shifting of the pixels to embed the watermark in the image.
